readme.txt
20221219 2140
Koji Mark Brannigan

RECIPE BUDDY

**********************************************************************************
OVERVIEW

Recipe Buddy is a database driven webapp which allows a user to find, add, edit 
and delete types of food, along with data abour their nutritional values.

**********************************************************************************
ERD

A fully fledged version of this app would have 3 tables as set out below. In order
to satisfy the brief, only the *food* table needs to be functional. The *bond* 
between recipe and food uses foreign keys to establish the link. For the sake 
of simplicity the *bond* table has a field with a unique identifier to serve as the
primary key, rather than use a composite key.

database *recipeBuddy*

table *recipe*                                                 table *bond*                                                   table *food*

                                                               |bondno     |INT(7) NOT NULL AUTO_INCREMENT|
|recipeno   |INT(7) NOT NULL AUTO_INCREMENT| ---one to many--- |recipeno   |INT(7)                        |
|recipetext |VARCHAR(50)                   |                   |id         |INT(7)                        | ---many to one--- |id         |INT(7) NOT NULL AUTO_INCREMENT|
                                                                                                                              |name       |VARCHAR(50)                   |
                                                                                                                              |carb       |DECIMAL(5,2)                  |
                                                                                                                              |fat        |DECIMAL(5,2)                  |
                                                                                                                              |protein    |DECIMAL(5,2)                  |	
                                                                                                    
PRIMARY KEY (recipeno)                                         PRIMARY KEY (bondno)                                           PRIMARY KEY (id)
INDEX (recipetext)                                             INDEX (recipeno)                                               INDEX (name)
                                                               INDEX (id)

**********************************************************************************
ENVIRONMENT

The necessary apps were installed on a computer at home, and that process took
longer than building the webapp itself.

**********************************************************************************
CODE

The files are all hand rolled, from first principles, allowing for the fact that a 
few short snippets of code were provided in the labs over the course of the module.

Much of the code resembles the work done on the Bertie's Book exercise, though a lot 
of refactoring was necessary. That means that the markers need to pay attention to 
every file in this list:

|path                       |file           |
|\miniproject\public        |main.css       |
|\miniproject\views         |list.ejs       |


The completely new addition to this webapp is the update feature which can be seen
at:

|path                       |file           |feature                 |line number(s)   |
|\miniproject\views         |list.ejs       |results table           |12-66            |
|\miniproject\views         |list.ejs       |update/delete forms     |51-60            |


