const bcrypt = require('bcrypt');
const {  check,  validationResult }  = require('express-validator');
const request = require('request');

module.exports = function(app, recipeData) {

    const redirectLogin = (req, res, next) => {
        if (!req.session.userId ) {
        res.redirect('./login')
        } else { next (); }
    }

    // Handle our routes
    app.get('/',function(req,res){
        res.render('index.ejs', recipeData)
    });

   //Week 4: Providing API, search a term

   app.get('/api', [check('keyword').not().isEmpty()], function (req,res) {

    const errors = validationResult(req);

    if (!errors.isEmpty()) {

        // res.redirect('./api');

        let sqlquery = "SELECT * FROM books"; // query database to get all the books

    // execute sql query

    db.query(sqlquery, (err, result) => {

        if (err) 
        {

            res.redirect('./'); 
        }
        else
        {
            res.json(result); 
        }
     });
    }
        else
        {
   //searching in the database

    let sqlquery = "SELECT * FROM books WHERE name LIKE '%" + req.query.keyword + "%'"; // query database to get all the books

    // execute sql query

    db.query(sqlquery, (err, result) => {
        if (err) {
            res.redirect('./'); 
        }else{
            res.json(result); 
        }
     });
    }
});

    app.get('/weather', function (req, res) {
                let apiKey = '088d54a94463b84b7709239e3aa98786'; 
                let city = 'London';
                let url = `http://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`
    
                request(url, function (err, response, body) {
                if(err){
                    console.log('error:', error);
                } else {
                    // res.send (body);
                    var weather = JSON.parse(body) 
                    var wmsg = 'It is '+ weather.main.temp +  
                        ' degrees in '+ weather.name + 
                        '! <br> The humidity now is: ' +  
                        weather.main.humidity; 
                    res.send (wmsg); 
                 } 
                });
            }); 
        
            app.get('/weatherform',function(req,res){
                res.render('weatherform.ejs', recipeData);
            });

            app.post('/weatherinfo', function (req, res) {
                
                let apiKey = '088d54a94463b84b7709239e3aa98786'; 
                let city = req.sanitize(req.body.city);
                let url = `http://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`
    
                request(url, function (err, response, body) {
                    var weather = JSON.parse(body) 
                    if (weather!==undefined && weather.main!==undefined) { 
                       var wmsg = '<h2 style="color: blue; text-align:center;"> It is '+ weather.main.temp +  
                          ' degrees in '+ weather.name + 
                          '! </h2><br><h2 style="color: blue; text-align:center;"> The humidity now is: ' +  
                          weather.main.humidity + '! </h2><br><h2 style="color: blue; text-align:center;"> The wind speed is:' + weather.wind.speed + ' metres per second</h2>'; 
                          res.send (wmsg); 
                    } 
                    else { 
                       res.send ("No data found"); 
                    } 
                });
            });
    
    

    app.get('/about',function(req,res){
        res.render('about.ejs', recipeData);
        
    });

/*
    app.get('/search-result', [check('keyword').not().isEmpty().isLength({min:1, max:30})], function (req, res) {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
        res.redirect('./search'); }
        //searching in the database
        //res.send("You searched for: " + req.query.keyword);
       
        else {
        let sqlquery = "SELECT * FROM books WHERE name LIKE '%" + req.query.keyword + "%'"; // query database to get all the books
        // execute sql query
        db.query(sqlquery, (err, result) => {
            if (err) {
                res.redirect('./'); 
            }
            let newData = Object.assign({}, recipeData, {availableBooks:result});
            console.log(newData)
            res.render("list.ejs", newData)
         });   
       }
    });
*/
    
// *******************************************************************************************************************************************************************
// Search
    
    app.get('/search', redirectLogin, function(req,res){
        res.render("search.ejs", recipeData);
    });
    
    app.get('/search-result', [check('keyword').not().isEmpty().isLength({min:1, max:30})], function (req, res) {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
        res.redirect('./search'); }
        //searching in the database
        //res.send("You searched for: " + req.query.keyword);

        // sanitize the input

        
       
        else {
        let sqlquery = "SELECT * FROM food WHERE name LIKE '%" + req.query.keyword + "%'"; // query database to get all the food
        // execute sql query
        db.query(sqlquery, (err, result) => {
            if (err) {
                res.redirect('./'); 
            }

            
            let newData = Object.assign({}, recipeData, {availableFoods:result});
            console.log(newData)
            res.render("list.ejs", newData)
         });   
       }
    });
    
    
    //delete (Task)
    app.get('/delete', redirectLogin, function (req,res) {
        res.render('delete.ejs', recipeData);                                                                     
    });
    app.post('/deleted', function (req,res) {

        // deleting data from database

        let sqlquery = "DELETE FROM accounts where username = ?";
        // execute sql query
        let newrecord = [req.body.username];

        db.query(sqlquery, newrecord, (err, result) => {
          if (err) {
            return console.error(err.message);
          }
          else
          res.send(' This user is deleted from the list, username: '+ req.sanitize(req.body.username)+'<p><a href='+'./'+'>Home</a></p>');
          });
      });
      

// *******************************************************************************************************************************************************************
// Login
      
    app.get('/login', function (req,res) {
        res.render('login.ejs', recipeData);                                                                     
    });

    app.post('/loggedin',[check('password').not().isEmpty().isLength({min:8, max:50})],
                         [check('username').not().isEmpty().isLength({min:1, max:30})], function (req,res) {
        // check for empty fields
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            res.redirect('./login'); }

        if (req.body.username == "" || req.body.password == ""){
            console.log("Empty fields");
            res.send('Please enter a valid username and password');
        }
        else {
            let sqlquery = "SELECT * FROM accounts WHERE username = '" +req.body.username+"'";

            // execute sql query

            db.query(sqlquery, (err, result) => {
                if(err){
                    console.log("Error getting users from database");
                    res.redirect('./')
                }
                else{
                    if(result.length == 0){
                        console.log("Please enter valid username and password");
                        res.send('Username or Password do not match'+'<p><a href='+'./'+'>Home</a></p>');
                    }
                    else{
                        const password = req.body.password;
                        let hashedPassword = result[0].hashedPassword
                        const bcrypt = require('bcrypt');

                        //compared password and hashedpassword

                        bcrypt.compare(password,hashedPassword, function(err, result1){
                            if(err){
                                //TODO: handle error
                                console.log(err);
                                res.redirect('./')
                            }

                            else if(result1 == true) {
                                // Save user session here, when login is successful
                                req.session.userId = req.sanitize(req.body.username);
                                console.log(Object.values(result[0])[1] + " is logged in at" + Date());
                                res.send(req.sanitize(req.body.username) + ' you are logged in!'+'<p><a href='+'./'+'>Home</a></p>');
                                

                            }
                            else{
                                // TODO send message
                                console.log("Username or Password do not match");
                                res.send('Username or Password do not match'+'<p><a href='+'./'+'>Home</a></p>');
                           } 

                            
                        });
                    }
                }
            });

        }



    });

// *******************************************************************************************************************************************************************
// Register

    app.get('/register', function (req,res) {
        res.render('register.ejs', recipeData);                                                                     
    });                                                                                                 
    app.post('/registered', [check('email'). isEmail()],
                            [check('password').not().isEmpty().isLength({min:8, max:50})], 
                            [check('username').not().isEmpty().isLength({min:1, max:30})], 
                            [check('first').not().isEmpty().isLength({min:1, max:30})], 
                            [check('last').not().isEmpty().isLength({min:1, max:30})], function (req, res) {

        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            res.redirect('./register'); }

        else {

                const saltRounds = 10; 

                const plainPassword = req.body.password;

                bcrypt.hash(plainPassword, saltRounds, function(err, hashedPassword) {

	            let sqlquery = "INSERT INTO accounts (username, first_name, last_name, email, hashedPassword) VALUES (?,?,?,?,?)";
	            let newrecord = [req.sanitize(req.body.username), req.sanitize(req.body.first), req.sanitize(req.body.last), req.sanitize(req.body.email), req.sanitize(hashedPassword)];

	            db.query(sqlquery, newrecord, (err, result) => {
	            if (err) {
	            return console.error(err.message);
	                }
	            else
                    result = 'Hello '+ req.sanitize(req.body.first) + ' '+ req.sanitize(req.body.last) +' you are now registered! We will send an email to you at ' + req.sanitize(req.body.email); result += ' Your password is: '+ req.sanitize(req.body.password) +' and your hashed password is: '+ req.sanitize(hashedPassword)+ '<p><a href='+'./'+'>Home</a></p>'; res.send(result);
	                }); 

                    })
                }
    }); 
    app.get('/list', redirectLogin, function(req, res) {
        let sqlquery = "SELECT * FROM food"; // query database to get all the foods
        // execute sql query
        db.query(sqlquery, (err, result) => {
            if (err) {
                res.redirect('./'); 
            }
            let newData = Object.assign({}, recipeData, {availableFoods:result});
            console.log(newData)
            res.render("list.ejs", newData)
         });
    });

    //listusers (Task)
    app.get('/listusers', redirectLogin, function(req, res) {
        let sqlquery = "SELECT * FROM accounts"; // query database to get all the accounts
        // execute sql query
        db.query(sqlquery, (err, result) => {
            if (err) {
                res.redirect('./'); 
            }
            let newDataUsers = Object.assign({}, recipeData, {availableUsers:result});
            console.log(newDataUsers)
            res.render("listusers.ejs", newDataUsers)
         });
    });




// *******************************************************************************************************************************************************************
// ADD FOOD

    
    app.get('/addfood', redirectLogin, function (req, res) {
        res.render('addfood.ejs', recipeData);
     });

     app.post('/foodadded', [check('name').not().isEmpty().isLength({min:1, max:50})], function (req,res) {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
        res.redirect('./addfood'); }

        else {
        // saving data in database
           let sqlquery = "INSERT INTO food (name, carb, fat, protein) VALUES (?,?,?,?)";
           // execute sql query
           let newrecord = [req.sanitize(req.body.name), req.sanitize(req.body.carb), req.sanitize(req.body.fat), req.sanitize(req.body.protein)];
           db.query(sqlquery, newrecord, (err, result) => {
             if (err) {
               return console.error(err.message);
             }
             else
             res.send(' This food is added to database, name: '+ req.sanitize(req.body.name) + 
                      ' carb '+ req.sanitize(req.body.carb) + 
                      ' fat '+ req.sanitize(req.body.fat)  + 
                      ' protein '+ req.sanitize(req.body.protein) +'<p><a href='+'./'+'>Home</a></p>');
             });
         }
    }); 

// *******************************************************************************************************************************************************************
// UPDATE FOOD

    
app.get('/updatefood', redirectLogin, function (req, res) {
    res.render('updatefood.ejs', recipeData);
 });

 app.post('/foodupdated', [check('id').not().isEmpty().isLength({min:1, max:50})], function (req,res) {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
    res.redirect('./updatefood'); }

    else {
    // saving data in database
       let sqlquery = "UPDATE food SET name = ?, carb = ?, fat = ?, protein = ? WHERE id = ?";
       // execute sql query
       let updatedrecord = [req.sanitize(req.body.name), req.sanitize(req.body.carb), req.sanitize(req.body.fat), req.sanitize(req.body.protein), req.sanitize(req.body.id)];
       db.query(sqlquery, updatedrecord, (err, result) => {
         if (err) {
           return console.error(err.message);
         }
         else
         res.send(' This food was updated in the database, name: '+ req.sanitize(req.body.name) + 
                  ' carb '+ req.sanitize(req.body.carb) + 
                  ' fat '+ req.sanitize(req.body.fat)  + 
                  ' protein '+ req.sanitize(req.body.protein) +'<p><a href='+'./'+'>Home</a></p>');
         });
     }
}); 
    
    








    
    

      



    //logout (Task)
    app.get('/logout', redirectLogin, (req,res) => {
        req.session.destroy(err => {
        if (err) {
        return res.redirect('./')
        }
        res.send('you are now logged out. <a href='+'./'+'>Home</a>');
        })
  })

}
