CREATE DATABASE myBookshop;
USE myBookshop;
CREATE TABLE books (id INT AUTO_INCREMENT,name VARCHAR(50),price DECIMAL(5, 2) unsigned,PRIMARY KEY(id));
INSERT INTO books (name, price)VALUES('database book', 40.25),('Node.js book', 25.00), ('Express book', 31.99) ;
CREATE USER 'appuser'@'localhost' IDENTIFIED WITH mysql_native_password BY 'Kitaharak0uji';
GRANT ALL PRIVILEGES ON myBookshop.* TO 'appuser'@'localhost';

# CREATE TABLE accounts (username VARCHAR(250),first_name VARCHAR(250), last_name VARCHAR(250), email VARCHAR(250), hashedPassword VARCHAR(250));

CREATE DATABASE recipeBuddy;
USE recipeBuddy;
CREATE TABLE food(id INT (7) NOT NULL AUTO_INCREMENT, name VARCHAR(50), carb DECIMAL(5, 2), fat DECIMAL(5, 2), protein DECIMAL(5, 2), PRIMARY KEY(id), INDEX(name));


CREATE TABLE accounts (username VARCHAR(250),first_name VARCHAR(250), last_name VARCHAR(250), email VARCHAR(250), hashedPassword VARCHAR(250));

CREATE USER 'appuser'@'localhost' IDENTIFIED WITH mysql_native_password BY 'Kitaharak0uji';
GRANT ALL PRIVILEGES ON recipeBuddy.* TO 'appuser'@'localhost';