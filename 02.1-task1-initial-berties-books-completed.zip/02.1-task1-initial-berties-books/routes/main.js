const bcrypt = require('bcrypt');

module.exports = function(app, shopData) {

    // Handle our routes
    app.get('/',function(req,res){
        res.render('index.ejs', shopData)
    });
    

    app.get('/about',function(req,res){
        res.render('about.ejs', shopData);
    });
    app.get('/search',function(req,res){
        res.render("search.ejs", shopData);
    });
    app.get('/search-result', function (req, res) {
        //searching in the database
        //res.send("You searched for: " + req.query.keyword);

        let sqlquery = "SELECT * FROM books WHERE name LIKE '%" + req.query.keyword + "%'"; // query database to get all the books
        // execute sql query
        db.query(sqlquery, (err, result) => {
            if (err) {
                res.redirect('./'); 
            }
            let newData = Object.assign({}, shopData, {availableBooks:result});
            console.log(newData)
            res.render("list.ejs", newData)
         });        
    });
    app.post('/deleted', function (req,res) {

        // deleting data from database

        let sqlquery = "DELETE FROM accounts where username = ?";
        // execute sql query
        let newrecord = [req.body.username];

        db.query(sqlquery, newrecord, (err, result) => {
          if (err) {
            return console.error(err.message);
          }
          else
          res.send(' This user is deleted from the list, username: '+ req.body.username);
          });
      });

    app.get('/login', function (req,res) {
        res.render('login.ejs', shopData);                                                                     
    });

    app.post('/loggedin', function (req,res) {
        // check for empty fields

        if (req.body.username == "" || req.body.password == ""){
            console.log("Empty fields");
            res.send('Please enter a valid username and password');
        }
        else {
            let sqlquery = "SELECT * FROM accounts WHERE username = '" + req.body.username + "'";

            // execute sql query

            db.query(sqlquery, (err, result) => {
                if(err){
                    console.log("Error getting users from database");
                    res.redirect('./')
                }
                else{
                    if(result.length == 0){
                        console.log("Please enter valid username and password");
                    }
                    else{
                        const password = req.body.password;
                        let hashedPassword = result[0].hashedPassword
                        const bcrypt = require('bcrypt');

                        //compared password and hashedpassword

                        bcrypt.compare(password,hashedPassword, function(err, result1){
                            if(err){
                                //TODO: handle error
                                console.log(err);
                                res.redirect('./')
                            }

                            else if(result1 == true) {
                                console.log(Object.values(result[0])[1] + " is logged in at" + Date());
                                res.send(req.body.username + ' you are logged in!');

                            }
                            else{
                                // TODO send message
                                console.log("Username or Password do not match");
                                res.send('Username or Password do not match');
                           } 

                            
                        });
                    }
                }
            });

        }



    });

    app.get('/register', function (req,res) {
        res.render('register.ejs', shopData);                                                                     
    });                                                                                                 
    app.post('/registered', function (req,res) {


        const saltRounds = 10; 

        const plainPassword = req.body.password;

        bcrypt.hash(plainPassword, saltRounds, function(err, hashedPassword) {

	let sqlquery = "INSERT INTO accounts (username, first_name, last_name, email, hashedPassword) VALUES (?,?,?,?,?)";
	let newrecord = [req.body.username, req.body.first, req.body.last, req.body.email, hashedPassword];

	db.query(sqlquery, newrecord, (err, result) => {
	if (err) {
	return console.error(err.message);
	}
	else
        result = 'Hello '+ req.body.first + ' '+ req.body.last +' you are now registered! We will send an email to you at ' + req.body.email; result += ' Your password is: '+ req.body.password +' and your hashed password is: '+ hashedPassword; res.send(result);
	}); 

    })

    }); 
    app.get('/list', function(req, res) {
        let sqlquery = "SELECT * FROM books"; // query database to get all the books
        // execute sql query
        db.query(sqlquery, (err, result) => {
            if (err) {
                res.redirect('./'); 
            }
            let newData = Object.assign({}, shopData, {availableBooks:result});
            console.log(newData)
            res.render("list.ejs", newData)
         });
    });

    app.get('/listusers', function(req, res) {
        let sqlquery = "SELECT * FROM accounts"; // query database to get all the accounts
        // execute sql query
        db.query(sqlquery, (err, result) => {
            if (err) {
                res.redirect('./'); 
            }
            let newDataUsers = Object.assign({}, shopData, {availableUsers:result});
            console.log(newDataUsers)
            res.render("listusers.ejs", newDataUsers)
         });
    });

    app.get('/addbook', function (req, res) {
        res.render('addbook.ejs', shopData);
     });
 
     app.post('/bookadded', function (req,res) {
           // saving data in database
           let sqlquery = "INSERT INTO books (name, price) VALUES (?,?)";
           // execute sql query
           let newrecord = [req.body.name, req.body.price];
           db.query(sqlquery, newrecord, (err, result) => {
             if (err) {
               return console.error(err.message);
             }
             else
             res.send(' This book is added to database, name: '+ req.body.name + ' price '+ req.body.price);
             });
       });    

       app.get('/bargainbooks', function(req, res) {
        let sqlquery = "SELECT * FROM books WHERE price < 20";
        db.query(sqlquery, (err, result) => {
          if (err) {
             res.redirect('./');
          }
          let newData = Object.assign({}, shopData, {availableBooks:result});
          console.log(newData)
          res.render("bargains.ejs", newData)
        });
    });       

}
